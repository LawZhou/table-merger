import java.util.Map;

public class RecordRow implements Comparable<RecordRow>{
    private final String id;
    private final Map<String, String> dataCols;

    public RecordRow(String id, Map<String, String> dataCols) {
        this.id = id;
        this.dataCols = dataCols;
    }

    public String getId() {
        return id;
    }

    public Map<String, String> getDataCols() {
        return dataCols;
    }

    @Override
    public int compareTo(RecordRow other) {
        return Integer.parseInt(this.id) - Integer.parseInt(other.getId());
    }
}
