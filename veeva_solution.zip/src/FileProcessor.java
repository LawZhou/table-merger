import java.util.List;

public interface FileProcessor {

     public RecordTable processTable();


}
