import java.util.List;

public class RecordTable {
    private List<String> headers;
    private List<RecordRow> rows;

    public RecordTable(List<String> headers, List<RecordRow> rows) {
        this.headers = headers;
        this.rows = rows;
    }

    public List<String> getHeaders() {
        return headers;
    }

    public List<RecordRow> getRows() {
        return rows;
    }
}
