import au.com.bytecode.opencsv.CSVParser;
import org.apache.commons.csv;
import java.util.List;

public class CSVProcessor implements FileProcessor {
    private String filename;

    public CSVProcessor(String filename) {
        this.filename = filename;
    }

    private CSVParser prepareParser() {
        CSVFormat
    }
    @Override
    public RecordTable processTable() {
        return null;
    }
}

